import styled from "styled-components";
import {LoginTemplate} from "../index"
export function Login() {

  return (
    <>
    <LoginTemplate />
    </>
  );
}
const Container = styled.div``;
