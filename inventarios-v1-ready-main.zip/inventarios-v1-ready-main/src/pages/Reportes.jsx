import {  ReportesTemplate} from "../index";
export function Reportes() {
  return (
   <ReportesTemplate/>
  );
}
