import styled from "styled-components";

export const ContentFiltros = styled.div`
  position: relative;
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
`;
