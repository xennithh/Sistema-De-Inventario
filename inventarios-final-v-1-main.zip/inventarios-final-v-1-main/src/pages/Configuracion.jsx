import styled from "styled-components";
import { ConfiguracionTemplate, Fondo1 } from "../index";
export function Configuracion() {
  return (
    <Container>
       
      <ConfiguracionTemplate />
    
    </Container>
  );
}
const Container = styled.main`
 height: 100vh;
`;
