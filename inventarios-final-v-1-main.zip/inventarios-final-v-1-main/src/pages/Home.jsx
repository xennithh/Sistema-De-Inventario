import styled from "styled-components";
import { HomeTemplate} from "../index";
export function Home() {

  return (
   <HomeTemplate/>
  );
}
